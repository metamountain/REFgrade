RefGrade - Krita Plugin
=======================
Install:
  1. Extract this ZIP into your Krita pykrita folder:
     Windows: %APPDATA%\krita\pykrita\
     Linux:   ~/.local/share/Krita/pykrita/
     macOS:   ~/Library/Application Support/Krita/pykrita/
  2. Restart Krita
  3. Find "RefGrade" under Filters menu

Requirements:
  - Krita 5.2+
  - Python 3.9+ (bundled with Krita)
  - torch (pip install torch) - for Color Replace
  - numpy, Pillow (usually pre-installed)
